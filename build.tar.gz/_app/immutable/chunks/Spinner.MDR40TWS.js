import{s as g,e as y,E as d,t as x,c as A,a as m,F as _,b as w,d as c,f as n,i as B,g as f,n as v}from"./scheduler.FQ2JQ4C6.js";import{S as E,i as j}from"./index.D7BjDufe.js";function N(p){let e,t,a,s,i,l;return{c(){e=y("div"),t=d("svg"),a=d("style"),s=x(`.spinner_ajPY {\r
				transform-origin: center;\r
				animation: spinner_AtaB 0.75s infinite linear;\r
			}\r
			@keyframes spinner_AtaB {\r
				100% {\r
					transform: rotate(360deg);\r
				}\r
			}\r
		`),i=d("path"),l=d("path"),this.h()},l(r){e=A(r,"DIV",{class:!0});var o=m(e);t=_(o,"svg",{class:!0,viewBox:!0,fill:!0,xmlns:!0});var h=m(t);a=_(h,"style",{});var u=m(a);s=w(u,`.spinner_ajPY {\r
				transform-origin: center;\r
				animation: spinner_AtaB 0.75s infinite linear;\r
			}\r
			@keyframes spinner_AtaB {\r
				100% {\r
					transform: rotate(360deg);\r
				}\r
			}\r
		`),u.forEach(c),i=_(h,"path",{d:!0,opacity:!0}),m(i).forEach(c),l=_(h,"path",{d:!0,class:!0}),m(l).forEach(c),h.forEach(c),o.forEach(c),this.h()},h(){n(i,"d","M12,1A11,11,0,1,0,23,12,11,11,0,0,0,12,1Zm0,19a8,8,0,1,1,8-8A8,8,0,0,1,12,20Z"),n(i,"opacity",".25"),n(l,"d","M10.14,1.16a11,11,0,0,0-9,8.92A1.59,1.59,0,0,0,2.46,12,1.52,1.52,0,0,0,4.11,10.7a8,8,0,0,1,6.66-6.61A1.42,1.42,0,0,0,12,2.69h0A1.57,1.57,0,0,0,10.14,1.16Z"),n(l,"class","spinner_ajPY"),n(t,"class",p[0]),n(t,"viewBox","0 0 24 24"),n(t,"fill","currentColor"),n(t,"xmlns","http://www.w3.org/2000/svg"),n(e,"class","flex justify-center text-center")},m(r,o){B(r,e,o),f(e,t),f(t,a),f(a,s),f(t,i),f(t,l)},p(r,[o]){o&1&&n(t,"class",r[0])},i:v,o:v,d(r){r&&c(e)}}}function S(p,e,t){let{className:a="size-5"}=e;return p.$$set=s=>{"className"in s&&t(0,a=s.className)},[a]}class Z extends E{constructor(e){super(),j(this,e,S,N,g,{className:0})}}export{Z as S};
//# sourceMappingURL=Spinner.MDR40TWS.js.map
