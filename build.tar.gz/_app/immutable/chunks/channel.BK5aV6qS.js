import{U as a,C as n}from"./Markdown.BGV6-GcY.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.BK5aV6qS.js.map
