import{U as a,C as n}from"./Markdown.Bakwp4kV.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.Bi2kbX3j.js.map
