import{U as a,C as n}from"./Messages.DqOlMPKy.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.DjL3IQpy.js.map
