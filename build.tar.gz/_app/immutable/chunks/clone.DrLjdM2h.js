import{b as r}from"./graph.CHdbrEQf.js";var e=4;function a(o){return r(o,e)}export{a as c};
//# sourceMappingURL=clone.DrLjdM2h.js.map
