function r(n){const u=n-1;return u*u*u+1}function c(n){return n/=.5,n<1?.5*n*n:(n--,-.5*(n*(n-2)-1))}function i(n){return--n*n*n*n*n+1}export{c as a,r as c,i as q};
//# sourceMappingURL=index.D5G1ZMhl.js.map
