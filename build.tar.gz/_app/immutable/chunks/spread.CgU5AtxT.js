function r(t,s){const c={},u={},f={$$scope:1};let i=t.length;for(;i--;){const o=t[i],e=s[i];if(e){for(const n in o)n in e||(u[n]=1);for(const n in e)f[n]||(c[n]=e[n],f[n]=1);t[i]=e}else for(const n in o)f[n]=1}for(const o in u)o in c||(c[o]=void 0);return c}function a(t){return typeof t=="object"&&t!==null?t:{}}export{a,r as g};
//# sourceMappingURL=spread.CgU5AtxT.js.map
