import{s as e}from"./entry.DVakeYWp.js";const r=()=>{const s=e;return{page:{subscribe:s.page.subscribe},navigating:{subscribe:s.navigating.subscribe},updated:s.updated}},b={subscribe(s){return r().page.subscribe(s)}};export{b as p};
//# sourceMappingURL=stores.DL3LldrS.js.map
