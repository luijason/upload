import{a as t}from"../chunks/entry.DylNFwDJ.js";export{t as start};
//# sourceMappingURL=start.A3JNkkSi.js.map
