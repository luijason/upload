import{a as t}from"../chunks/entry.BFmMI4Sv.js";export{t as start};
//# sourceMappingURL=start.B4AgOsG2.js.map
