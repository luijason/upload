import{a as t}from"../chunks/entry.AQjirlx3.js";export{t as start};
//# sourceMappingURL=start.BCUbIY0L.js.map
