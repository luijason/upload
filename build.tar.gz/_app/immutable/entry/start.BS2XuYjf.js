import{a as t}from"../chunks/entry.YKscJZIf.js";export{t as start};
//# sourceMappingURL=start.BS2XuYjf.js.map
