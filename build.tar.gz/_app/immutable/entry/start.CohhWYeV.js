import{a as t}from"../chunks/entry.CUOIoVP9.js";export{t as start};
//# sourceMappingURL=start.CohhWYeV.js.map
