import{a as t}from"../chunks/entry.Cfbeke3M.js";export{t as start};
//# sourceMappingURL=start.CsjnX8j0.js.map
