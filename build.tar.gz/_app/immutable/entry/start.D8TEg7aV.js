import{a as t}from"../chunks/entry.Fv6BG_E6.js";export{t as start};
//# sourceMappingURL=start.D8TEg7aV.js.map
