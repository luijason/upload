import{a as t}from"../chunks/entry.2lcKRrZN.js";export{t as start};
//# sourceMappingURL=start.DY5iIGbq.js.map
