import{a as t}from"../chunks/entry.Dxxhcs_Z.js";export{t as start};
//# sourceMappingURL=start.Dm2Qqqe7.js.map
