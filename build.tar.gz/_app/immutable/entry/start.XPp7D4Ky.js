import{a as t}from"../chunks/entry.DVakeYWp.js";export{t as start};
//# sourceMappingURL=start.XPp7D4Ky.js.map
