import{s as n,q as s}from"../chunks/scheduler.FQ2JQ4C6.js";import{S as e,i as a}from"../chunks/index.D7BjDufe.js";import{g as r}from"../chunks/entry.CUOIoVP9.js";function i(o){return s(()=>{r("/admin/functions/create")}),[]}class f extends e{constructor(t){super(),a(this,t,i,null,n,{})}}export{f as component};
//# sourceMappingURL=19.f3uj1T3Y.js.map
