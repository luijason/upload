import{s as n,q as s}from"../chunks/scheduler.BUEsFZp5.js";import{S as e,i as a}from"../chunks/index.DMbsBxcm.js";import{g as r}from"../chunks/entry.Cfbeke3M.js";function i(o){return s(()=>{r("/admin/functions/create")}),[]}class f extends e{constructor(t){super(),a(this,t,i,null,n,{})}}export{f as component};
//# sourceMappingURL=20.DvtTjDr_.js.map
