import{s as n,q as s}from"../chunks/scheduler.DTGPXjXK.js";import{S as e,i as a}from"../chunks/index.C8mn3DpP.js";import{g as r}from"../chunks/entry.CqokkhXf.js";function i(o){return s(()=>{r("/admin/functions/create")}),[]}class f extends e{constructor(t){super(),a(this,t,i,null,n,{})}}export{f as component};
//# sourceMappingURL=20.SSQbl4r_.js.map
