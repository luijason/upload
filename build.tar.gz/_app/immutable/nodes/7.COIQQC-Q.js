import{s as t,q as n}from"../chunks/scheduler.DTGPXjXK.js";import{S as e,i as r}from"../chunks/index.C8mn3DpP.js";import{g as a}from"../chunks/entry.ByIryjAm.js";function i(o){return n(()=>{a("/admin/users")}),[]}class c extends e{constructor(s){super(),r(this,s,i,null,t,{})}}export{c as component};
//# sourceMappingURL=7.COIQQC-Q.js.map
