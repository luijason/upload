import{s as t,q as n}from"../chunks/scheduler.FQ2JQ4C6.js";import{S as e,i as r}from"../chunks/index.D7BjDufe.js";import{g as a}from"../chunks/entry.AQjirlx3.js";function i(o){return n(()=>{a("/admin/users")}),[]}class c extends e{constructor(s){super(),r(this,s,i,null,t,{})}}export{c as component};
//# sourceMappingURL=7.T_JvXy_N.js.map
