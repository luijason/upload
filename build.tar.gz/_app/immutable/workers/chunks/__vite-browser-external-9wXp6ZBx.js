var e={};export{e as default};
//# sourceMappingURL=__vite-browser-external-9wXp6ZBx.js.map
